#include "booking_portal.c"
#include "admin_sys.c"
#ifndef _COLOR_CHANGE
    #include "color_changer.c"
#endif


int main()
{  
     
    admin_sys();
    return 0;
}